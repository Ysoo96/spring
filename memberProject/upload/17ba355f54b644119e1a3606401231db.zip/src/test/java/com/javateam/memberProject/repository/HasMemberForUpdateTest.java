package com.javateam.memberProject.repository;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
class HasMemberForUpdateTest {
	
	@Autowired
	MemberDAO memberDAO;

	// case-1) 이메일(EMAIL) 중복 점검
	// case-1-1) 회원 기존 메일로 재사용 점검
	@Test
	void testHasMemberForUpdate() {

		assertFalse(memberDAO.hasMemberForUpdate("abcd1111", "EMAIL", "abcd1111@abcd.com"));
	}
	
	// case-1-2) 신규 메일 사용 => 다른 회원과 메일 중복되는 메일 사용 점검
	@Test
	void testHasMemberForUpdate2() {

		assertTrue(memberDAO.hasMemberForUpdate("abcd1111", "EMAIL", "mbc_23@abcd.com"));
	}

	// case-1-3) 신규 메일 사용 => 다른 회원과 메일 중복되지 않는 메일 사용 점검
	@Test
	void testHasMemberForUpdate3() {

		assertFalse(memberDAO.hasMemberForUpdate("abcd1111", "EMAIL", "mbcmbc@abcd.com"));
	}
	
	// case-2) 휴대폰(MOBILE) 중복 점검
	// case-2-1) 회원 기존 휴대폰로 재사용 점검
	@Test
	void testHasMemberForUpdate4() {

		assertFalse(memberDAO.hasMemberForUpdate("abcd1111", "MOBILE", "010-1111-3333"));
	}
	
	// case-2-2) 신규 휴대폰 사용 => 다른 회원과 휴대폰 중복되는 휴대폰 사용 점검
	@Test
	void testHasMemberForUpdate5() {

		assertTrue(memberDAO.hasMemberForUpdate("abcd1111", "MOBILE", "010-2222-3434"));
	}

	// case-2-3) 신규 휴대폰 사용 => 다른 회원과 휴대폰 중복되지 않는 휴대폰 사용 점검
	@Test
	void testHasMemberForUpdate6() {

		assertFalse(memberDAO.hasMemberForUpdate("abcd1111", "MOBILE", "mbcmbc@abcd.com"));
	}
	
}