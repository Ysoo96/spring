package com.javateam.memberProject.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.javateam.memberProject.domain.MemberVO;

@SpringBootTest
class MemberDAOTest {
	
	@Autowired
	MemberDAO memberDAO;

	// 개별 회원 정보를 조회
	// case) id(mbc_1023)인 회원정보의 이름이 "장갑인"인지 점검
	@Test
	void testSelectMemberById() {
		
		MemberVO memberVO = memberDAO.selectMemberById("mbc_1023");
		// assertNotEquals("홍길동", memberVO.getName());
		// assertEquals("홍길동", memberVO.getName());
		assertEquals("장갑인", memberVO.getName());
	}
	
	// 페이징에 의한 회원정보 조회
	// case-1) 레코드의 길이 = 10
	// case-2) page=1 에서 첫 인원의 이름(장갑인), 
	// 마지막 인원의 이름(권나섭)으로 검수
	
	@Test
	void testSelectMembersByPaging() {
		
		// case-1)
		List<MemberVO> members = memberDAO.selectMembersByPaging(1, 10);
		assertEquals(10, members.size());
		
		// case-2)
		assertEquals("장갑인", members.get(0).getName());
		assertEquals("권나섭", members.get(9).getName());
	}
	

}
